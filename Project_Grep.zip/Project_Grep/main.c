#include<stdio.h>
#include<stdlib.h>
#include"grep.h"
#include"grep.c"

int main(){

    List DS;
    init(&DS);
    char filename[20] = "sample.txt";
    fetch_all_data(&DS,filename);
    char pattern[500];
    int ch;
    
    do{
        printf("\n\t\t ----------   GREP IMPLEMENTATION IN 'C' ---------- ");
        printf("\n\n\t Here are some options to perform on file \n\t File Name : %s",filename);
        printf("\n\t OPTIONS ARE ==>");
        printf("\n\n\t 1. -c  : To Count the Number of Matched Lines in a File");
        printf("\n\n\t 2. -v  : To Print Lines Without Matching Pattern from File");
        printf("\n\n\t 3. -m2 : To Print First Two Matches of Pattern With Line Number");
        printf("\n\n\t 4. -w  : To Prints Lines With Matching Pattern of whole words only");
        printf("\n\n\t 5. -n  : To Print Matching Pattern Lines Preceded By Their Line Numbers");
        printf("\n\n\t 0.       EXIT ");
        printf("\n\n\t Enter you option : ");
        scanf("%d",&ch);
        switch(ch){
            case 1:{
                printf("\n\t Enter Pattern to Match : ");
                scanf("%s",&pattern);
                int result = grep_c(DS,pattern);
                if(result != INT_MAX && result != 0)
                    printf("\n\t Matched Lines Count: %d, file name : %s, pattern : %s",result,filename,pattern);
            }
            break;
            case 2:{
                printf("\n\t Enter Pattern to Match : ");
                scanf("%s",&pattern);
                grep_v(DS,pattern);
            }
            break;
            case 3:{
                printf("\n\t Enter Pattern to Match : ");
                scanf("%s",&pattern);
                grep_m2(DS,pattern);
            }
            break;
            case 4:{
                printf("\n\t Enter Pattern to Match : ");
                scanf("%s",&pattern);
                grep_w(DS,pattern);
            }
            break;
            case 5:{
                printf("\n\t Enter Pattern to Match : ");
                scanf("%s",&pattern);
                grep_n(DS,pattern);
            }
            break;
        }
    }while(ch != 0);
    return 0;
}