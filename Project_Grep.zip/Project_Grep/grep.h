
#ifndef grep_h
#define grep_h

typedef struct node{
    char filename[20];
    char line[500];
    int word_count;
    int space_count;
    int line_count;
    struct node *next;
}node;

typedef node* List;

// to initialise data structure;
void init(List *head);  
// to fetch the data of file in the data structure
void fetch_file_data(List *head,char filename[20]);
// it is to add the node if line into DS
void append(List *head, char line[500],char filename[20]);
// to count words in a line
void word_line_count(List *head);
// to count space in line
void space_count(List *head);
// to call all the necessry functions together
void fetch_all_data(List *head,char filename[20]);
// for -c option
int grep_c(List head,char pattern[50]);
// for -v option
int grep_v(List head, char pattern[50]);
//for option -m2
void grep_m2(List head, char pattern[50]);
//for -w option
void grep_w(List head, char pattern[50]);
//for -n option
void grep_n(List head,char pattern[50]);
// for comparing pattern
int my_str_cmp(char w[20], char p[20]);
// for comparig whole word
int cmp_whole_word(char w[10], char p[10]);
#endif