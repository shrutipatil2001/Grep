#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"grep.h"
const int Buffer = 500;
/*typedef struct node{
    char *filename;
    char *line;
    int word_count;
    int space_count;
    int line_count;
    struct node *next;
}node;*/

//to initialise Data Structure
void init(List *head){
    *head = NULL;
    return;
}

//to fetch data from file
void fetch_file_data(List *head, char filename[20]){
    char temp[Buffer];
    FILE *fp = fopen(filename,"r");
    if(!fp)
        printf("\n\t FILE NOT EXIST!!!");
    while(!feof(fp)){
        fgets(temp,Buffer,fp);  // function to read line
        append(head,temp,filename); // adding line node to DS
    }
    fclose(fp);
    return;
}
//to append node in Data Structure
void append(List *head,char line[Buffer],char filename[20]){
    node *nn = (node*)malloc(sizeof(node));   // creating a node for line
    if(nn){
        strcpy(nn->filename,filename);
        strcpy(nn->line,line);
        nn->next = NULL;
    }
    if(*head == NULL){
        *head = nn;
    }
    else{
        node *ptr = *head;
        while(ptr->next != NULL){
            ptr = ptr->next;
        }
        ptr->next = nn;
    }
}

//to count word in line 
void word_line_count(List *head){
    node *ptr = *head;
    char *word;
    int lcount = 0;
    char line[Buffer];
    int wcount = 0;
    if(*head == NULL){
        return;
    }
    else{
        while(ptr != NULL){
            lcount++;
            strcpy(line,ptr->line);
            word = strtok(line," ");  //split lines into words
            while(word != NULL ){
                wcount++;
                word = strtok(NULL," ");
            }
            ptr->word_count = wcount;
            ptr->line_count = lcount;
            wcount = 0;
            ptr = ptr->next;
        }
    }
    
}
//to count number of space in a line
void space_count(List *head){
    node *ptr = *head;
    int sp = 0;
    if(*head == NULL)
        return;
    else{
        node *ptr = *head;
        while(ptr != NULL){
            int len = strlen(ptr->line);
            char a[Buffer];
            strcpy(a,ptr->line);
            int i;
            for(i = 0; i < len-1; i++){
               if(a[i] == ' ')
                    sp++; 
            }
            ptr->space_count = sp;
            sp  = 0;
            ptr = ptr->next;
        }
    }
}

//to fetch all data
void fetch_all_data(List *head, char filename[20]){
    fetch_file_data(head,filename);
    word_line_count(head);
    space_count(head);
}

// function for option -c , returns match count
int grep_c(List head,char pattern[50]){
    char line[500];
    int match_count = 0;
    char *word;
    if(head == NULL)
        return INT_MAX;
    else{
        node *ptr = head;
        while(ptr != NULL){
            strcpy(line, ptr->line);
            word = strtok(line," ");
            while(word != NULL ){
                if(my_str_cmp(word,pattern) == 0){
                    match_count++;
                    break;
                }
                word = strtok(NULL," \n");
            }
            ptr = ptr->next;
        }
    }
    return match_count;
}

//function for option -v, return no of lines
int grep_v(List head, char pattern[50]){
    char line[500];
    int count = 0;
    int flag = -1;
    char *word;
    if(head == NULL)
        return INT_MAX;
    else{
        node *ptr = head;
        while(ptr != NULL){
            strcpy(line, ptr->line);
            word = strtok(line," ");
            while(word != NULL ){
                if(my_str_cmp(word,pattern) == 0)
                    flag = 0;
                word = strtok(NULL," \n");
            }
            if(flag == 0){
                flag = -1;
            }
            else{
                count++;
                printf("\n\t line: %d, %s",ptr->line_count,ptr->line);
                flag = -1;
            }
            ptr = ptr->next;
        }
    }
    return count;
}
//function for -m2 option returns
void grep_m2(List head, char pattern[50]){
    char line[500];
    int count = -1;
    char *word;
    if(head == NULL)
        return;
    else{
        node *ptr = head;
        while(ptr != NULL){
            strcpy(line, ptr->line);
            word = strtok(line," ");
            while(word != NULL ){
                if(my_str_cmp(word,pattern) == 0){
                    count++;
                    if(count >= 2)
                        break;
                    else
                        printf("\n\t line: %d, %s",ptr->line_count,ptr->line);
                }
                word = strtok(NULL," \n");
            }
            ptr = ptr->next;
        }
    }
    return;
}

//function for -i option
void grep_w(List head,char pattern[50]){
    char line[Buffer];
    char *word;
    if(head == NULL)
        return;
    else{
        node *ptr = head;
        while(ptr != NULL){
            strcpy(line, ptr->line);
            word = strtok(line," ");
            while(word != NULL ){
                if(cmp_whole_word(word,pattern) == 0){
                    printf("\n\t %s",ptr->line);
                }
                word = strtok(NULL," \n");
            }
            ptr = ptr->next;
        }
    }
    return;
}

//function for option n
void grep_n(List head,char pattern[50]){
    char line[Buffer];
    char *word;
    if(head == NULL)
        return;
    else{
        node *ptr = head;
        while(ptr != NULL){
            strcpy(line, ptr->line);
            word = strtok(line," ");
            while(word != NULL ){
                if(my_str_cmp(word,pattern) == 0){
                    printf("\n\t line: %d, %s",ptr->line_count,ptr->line);
                }
                word = strtok(NULL," \n");
            }
            ptr = ptr->next;
        }
    }
    return;
} 


//function for comparing string
int my_str_cmp(char w[10], char p[10]){    
    int w1,p1;
    w1 = strlen(w);
    p1 = strlen(p);
    int ch = 0;
    if(w1 >= p1){
        for(int i = 0; i < p1; i++){
            if(w[i] == p[i])
                ch++;
        }
        if(ch == p1){
            return 0;
        }
        else{
            return 1;
        }
    }
    else{
        return -1;
    }
}
//function to match whole words
int cmp_whole_word(char w[10], char p[10]){    
    int w1,p1;
    w1 = strlen(w);
    p1 = strlen(p);
    int ch = 0;
    if(w1 == p1){
        for(int i = 0; i < p1; i++){
            if(w[i] == p[i])
                ch++;
        }
        if(ch == p1){
            return 0;
        }
        else{
            return 1;
        }
    }
    else{
        return -1;
    }
}

